﻿/*  George Tang
 *  Assignement 6
 * script not used
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Inventoryitem
{
    public int id;
    public string name;

}
