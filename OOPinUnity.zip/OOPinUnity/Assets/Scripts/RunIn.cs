﻿/*  George Tang
 *  Assignement 6
 * Jumpin Game and game starts allowing player to run around while tutorial is running
 */
using UnityEngine;
using System.Collections;

public interface RunIn
{
    void Jump();
}
