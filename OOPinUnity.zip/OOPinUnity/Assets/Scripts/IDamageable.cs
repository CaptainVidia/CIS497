﻿using UnityEngine;
using System.Collections;

public interface IDamageable 
{
    void TakeDamge(int amount);
    
}
